<?php

	@session_start();
	@extract($_REQUEST);

	/*Globales */

	$divisa = "$";
	$iva = 0.13;

?>